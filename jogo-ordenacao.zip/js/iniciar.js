/* Inicialização */
preencheAlgo();
desenhaLista();
